<?php
    require_once 'connection.php';

    if(isset($_POST['submit'])){
        $username1 = $_POST['uname'];
        $email1 = $_POST['emailid'];
        $password1 = $_POST['password'];
        $cpassword1=$_POST['cpassword'];
        // encrypt

        $pass = md5($password1);

        $emailquery =" select * from users where email = '$email1'";
        $userquery = " select * from users where username = '$username1'";

        $query = mysqli_query($conn,$emailquery);

        $query1 = mysqli_query($conn,$userquery);

        $emailcount = mysqli_num_rows($query);
        $usernamecount = mysqli_num_rows($query1);

        if($emailcount>0){
            $email1_error = 'EmailID already Exist.';
        }
        elseif ($usernamecount>0) {
            $username1_error = 'Username already Exist.';
        }
        else{
            if($password1 == $cpassword1){

                $insertquery = "insert into users(email,username,password)values('$email1','$username1','$pass')";

                $iquery = mysqli_query($conn,$insertquery);

                if($iquery){
                    ?>
                        <script>
                            alert("Successfully Registered.");
                            location.replace("login.php");
                        </script>
                    <?php

                    }else{
                    ?>
                        <script>
                            alert("Failed.");
                        </script>
                    <?php

                }

            }else{
                $pass1_error = 'Password are not matching.';
            }
        }




    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="lightslider/dist/css/lightslider.css">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="icofont/icofont.min.css" rel="stylesheet"> 
    <link href="animate.css/animate.min.css" rel="stylesheet"> 
    <link href="owl.carousel/owl.carousel.min.css" rel="stylesheet">
    <link rel="stylesheet" href="material-icon/css/material-design-iconic-font.min.css">
    <!-- animate on scroll -->
    <link href="aos/aos.css" rel="stylesheet">

    <!-- custom CSS File -->
    <link href="style1.css" rel="stylesheet">
    
</head>
<body>
  <section class="signup">
        <div class="container">
            <div class="signup-content">
                <div class="signup-form">
                    <h2 class="form-title">Sign up</h2>
                    <form method="POST" class="register-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                        <div class="form-group">
                            <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                            <input type="text" name="uname" id="name" placeholder="Username"/>
                        </div>
                        <div style="text-align: left; margin-top: -20px;" >
                            <?php 
                                if(isset($username1_error)){
                                    ?><p style="color: #d93025;"><?php echo $username1_error ?></p><?php
                                }
                            ?>
                        </div>                        
                        <div class="form-group">
                            <label for="email"><i class="zmdi zmdi-email"></i></label>
                            <input type="email" name="emailid" id="email" placeholder="Your Email"/>
                        </div>
                        <div style="text-align: left; margin-top: -20px;" >
                            <?php 
                                if(isset($email1_error)){
                                    ?><p style="color: #d93025;"><?php echo $email1_error ?></p><?php
                                }
                            ?>
                        </div>
                        <div class="form-group">
                            <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                            <input type="password" name="password" id="pass" placeholder="Password"/>
                        </div>
                        <div class="form-group">
                            <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                            <input type="password" name="cpassword" id="re_pass" placeholder="Repeat your password"/>
                        </div>
                        <div style="text-align: left; margin-top: -20px;" >
                            <?php 
                                if(isset($pass1_error)){
                                    ?><p style="color: #d93025;"><?php echo $pass1_error ?></p><?php
                                }
                            ?>
                        </div> 
                        <div class="form-group form-button">
                            <input type="submit" name="submit" id="signup" class="form-submit" value="Register"/>
                        </div>
                    </form>
                </div>
                <div class="signup-image">
                    <figure><img src="img/reg.png" alt="sing up image"></figure>
                    <a href="login.php" class="signup-image-link">I am already member</a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>