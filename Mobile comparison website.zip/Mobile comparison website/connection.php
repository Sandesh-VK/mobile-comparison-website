<?php
$conn = mysqli_connect('localhost','root','','mobcompare');

if (!$conn){
	echo "Not connected";
	exit();
}

?>