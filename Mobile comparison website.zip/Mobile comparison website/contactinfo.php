<?php
	require_once 'connection.php';
    if(isset($_POST['submit1'])){
        $insertquery = "insert into contact(name,phoneno,email,message)values('$email1','$username1','$pass')";

        $iquery = mysqli_query($conn,$insertquery);

            if($iquery){
                ?>
                    <script>
                         alert("Successfully Registered.");
                        location.replace("login.php");
                    </script>
                <?php

                }else{
                ?>
                     <script>
                         alert("Failed.");
                     </script>
                <?php

            }
    }
?>