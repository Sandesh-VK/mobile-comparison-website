<?php
require_once 'connection.php';
$ph1exist=0;
if (isset($_GET["ph1"])) {
  $ph1=$_GET["ph1"];
  $sql = "SELECT * FROM mobileinfo WHERE mobid='$ph1'";
  $result = $conn->query($sql);
  $ph1exist=0;
  if ($result->num_rows > 0) {
    $ph1exist=1;
    $ph1row = $result->fetch_assoc();
  }
}
$ph2exist=0;
if (isset($_GET["ph2"])) {
  $ph2=$_GET["ph2"];
  $sql = "SELECT * FROM mobileinfo WHERE mobid='$ph2'";
  $result = $conn->query($sql);
  $ph2exist=0;
  if ($result->num_rows > 0) {
    $ph2exist=1;
    $ph2row = $result->fetch_assoc();
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Mobile Comparison</title>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <!-- bootstrapcdn -->
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- icofont -->
  <link href="icofont/icofont.min.css" rel="stylesheet"> 
  <!-- animate css -->
  <link href="animate.css/animate.min.css" rel="stylesheet"> 
  <!-- owl carousel -->
  <link href="owl.carousel/owl.carousel.min.css" rel="stylesheet">
  <!-- animate on scroll -->
  <link href="aos/aos.css" rel="stylesheet">
  <!-- custom CSS File -->
  <link href="table.css" rel="stylesheet">
  <!-- fontawsome -->
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- lightslider -->
  <link rel="stylesheet" href="lightslider/dist/css/lightslider.css">
</head>
<body> 
   <header id="header">
    <div class="container d-flex animate__animated animate__fadeInUp " style="animation-duration: 2s;">

      <div class="logo mr-auto">
        <h1><a href="homepage.html"><b>Mobile Comparison</b></a></h1>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="homepage.php">Home</a></li>
          <li><a href="compare.php">Compare</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#contact">Contact</a></li>           
          <li><a href="login.php">Login / Register</a></li>
           
        </ul>
      </nav>

    </div>
  </header>

    <form action="phpfile.php" method="POST">
    <div class="container" style="padding-top: 50px; padding-bottom: 50px;">
    <table>
        <tr>
          <th style="width:40%"></th>
          <th>
            <div class="md-form mt-0 searchbox">
                <input class="form-control" name="Search" id="Search1" type="text" placeholder="Add a mobile" aria-label="Search" value="<?php if($ph1exist){echo $ph1row["model"]; }?>">
                <div id="list1">
                <ul>
                                           
                </ul>
            </div>
            </div>
            
          </th>
          <th>
            <div class="md-form mt-0 searchbox">
                <input class="form-control" type="text" id="Search2" placeholder="Add a mobile" aria-label="Search" value="<?php if($ph2exist){echo $ph2row["model"]; }?>">
                <div id="list2">
                <ul>
                                           
                </ul>
            </div>
            </div>
            
          </th>
        </tr>
        <tr>
          <th style="width:20%"></th>
          <th>
            <?php if ($ph1exist) { ?>
            <img src="img/<?php
            echo $ph1row["thumbnail"];
          ?>" alt="1">
          <?php } ?>
        </th>
          <th>
            <?php if ($ph2exist) { ?>
              <img src="img/<?php
            echo $ph2row["thumbnail"];
          ?>" alt="1">
          <?php } ?>
        </th>
        </tr>
        <tr>
          <td>Model</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["model"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["model"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Processor</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["processor"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["processor"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Ram</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["ram"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["ram"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Display</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["display"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["display"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Camera</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["camera"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["camera"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Storage</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["storage"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["storage"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Battery</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["battery"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["battery"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Sim</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["sim"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["sim"];
          }
          ?></td>
        </tr>
        <tr>
          <td>Price</td>
          <td><?php
          if ($ph1exist) {
            echo $ph1row["price"];
          }
          ?></td>
          <td><?php
          if ($ph2exist) {
            echo $ph2row["price"];
          }
          ?></td>
        </tr>
      </table>
    </div>
  </form>
    <footer class="footer">
            <div class="footer-left col-md-4 col-sm-6">
              <p class="about" style="font-size: 20px;">
                This is just a college project.
              </p>
              <div class="icons">
                <a href="#"><i class="icofont-facebook"></i></a>
                <a href="#"><i class="icofont-twitter"></i></a>
                <a href="#"><i class="icofont-linkedin"></i></a>
                <a href="#"><i class="icofont-instagram"></i></i></a>
                
              </div>
            </div>
            <div class="footer-center col-md-4 col-sm-6">
              <div>
                <i class="icofont-location-pin"></i>
                <p><span> J.M road</span> Mumbai, India</p>
              </div>
              <div>
                <i class="icofont-smart-phone"></i>
                <p> 0123456789</p>
              </div>
              <div>
                <i class="icofont-email"></i>
                <p><a href="#">sandesh03@gmail.com</a></p>
              </div>
            </div>
            <div class="footer-right col-md-4 col-sm-6">
              <h2>Mobile<span>Comparison</span></h2>
              <p class="menu">
                <a href="#"> Home</a> |
                <a href="#"> Compare</a> |
                <a href="#"> About</a> |              
                <a href="#"> Contact</a>
              </p>
              
            </div>
          </footer>
          <!--footer-end-->
          <script src="">js/smooth-scroll.js</script>
          <script>
            var scroll= new SmoothScroll('a[href*="#"]');
          </script>
  
 <!-- js files          -->
  <script src="wow/wow.min.js"></script>
  <script>
    new WOW().init();
  </script>
  <script src="jquery/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>  
  <script src="owl.carousel/owl.carousel.min.js"></script>
  <script src="js/main.js"></script>
  <script src="lightslider/dist/js/lightslider.js"></script>

  <!-- lightslider js -->
  <script>
    const ph1="<?php if ($ph1exist) {echo $ph1row["mobid"]; }else{echo ""; } ?>";
    const ph2="<?php if ($ph2exist) {echo $ph2row["mobid"]; }else{echo ""; } ?>";
    $(document).ready(function() {
    $('#autoWidth').lightSlider({
        autoWidth:true,
        loop:true,
        auto:true,
        onSliderLoad: function() {
            $('#autoWidth').removeClass('cS-hidden');
        } 
    });  
  });

    // compare

    $("#Search1").on("input", function() {
  let search = $("#Search1").val().trim();
  if (search.length>2) {
    $.post("list.php",
    {
    search: search
    },
    function(data, status){
      if (data!="0") {
        let html='';
        data.forEach(function (item, index) {

          html+='<li><a href="?ph1='+item.mobid+'&ph2='+ph2+'"><img src="img/'+item.thumbnail+'"><div class="text">'+item.model+'</div></a></li>';
        }); 
        $("#list1 ul").html(html);
        $("#list1").css("display","block");
      }else{
        $("#list1 ul").html("<li>No result found</li>");      
        $("#list1").css("display","block"); 
      }
    })
  }
  else{
    $("#list1").css("display","none");
  }
});
    $("#Search2").on("input", function() {
  let search = $("#Search2").val().trim();
  if (search.length>2) {
    $.post("list.php",
    {
    search: search
    },
    function(data, status){
      if (data!="0") {
        let html='';
        data.forEach(function (item, index) {
          html+='<li><a href="?ph1='+ph1+'&ph2='+item.mobid+'"><img src="img/'+item.thumbnail+'"><div class="text">'+item.model+'</div></a></li>';
        }); 
        $("#list2 ul").html(html);
        $("#list2").css("display","block");
      }else{
        $("#list2 ul").html("<li>No result found</li>");      
        $("#list2").css("display","block"); 
      }
    })
  }
  else{
    $("#list1").css("display","none");
  }
});

  </script>
</body>
</html>