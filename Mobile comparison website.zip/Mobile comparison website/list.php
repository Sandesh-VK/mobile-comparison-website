<?php
header("Content-Type: application/json; charset=UTF-8");
require_once 'connection.php';
$search=$_POST["search"];
$sql = "SELECT * FROM mobileinfo WHERE model LIKE '%$search%'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $outp = $result->fetch_all(MYSQLI_ASSOC);
  $mobileData=array();
  foreach ($outp as $key => $value) {
  	$mobileData[$key]["mobid"]=$value["mobid"];
  	$mobileData[$key]["model"]=$value["model"];
  	$mobileData[$key]["mobname"]=$value["mobname"];
  	$mobileData[$key]["thumbnail"]=$value["thumbnail"];

  }
  echo $jsonformat=json_encode($mobileData);
 
} else {
  echo "0";
}
?>