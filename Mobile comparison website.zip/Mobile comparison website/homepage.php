<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Mobile Comparison</title>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <!-- bootstrapcdn -->
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- icofont -->
  <link href="icofont/icofont.min.css" rel="stylesheet"> 
  <!-- animate css -->
  <link href="animate.css/animate.min.css" rel="stylesheet"> 
  <!-- owl carousel -->
  <link href="owl.carousel/owl.carousel.min.css" rel="stylesheet">
  <!-- animate on scroll -->
  <link href="aos/aos.css" rel="stylesheet">
  <!-- custom CSS File -->
  <link href="style.css" rel="stylesheet">
  <!-- fontawsome -->
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- lightslider -->
  <link rel="stylesheet" href="lightslider/dist/css/lightslider.css">
</head>
<body>
  
    <!--  Header  -->
  <header id="header">
    <div class="container d-flex animate__animated animate__fadeInUp " style="animation-duration: 2s;">

      <div class="logo mr-auto">
        <h1><a href="homepage.html"><b>Mobile Comparison</b></a></h1>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="homepage.php">Home</a></li>
          <li><a href="compare.php">Compare</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#contact">Contact</a></li> 
          <?php if (!isset($_SESSION["loggedin"])) { ?>          
          <li><a href="login.php">Login / Register</a></li><?php }else{ ?>
          <li><a href="logout.php">LogOut</a></li><?php } ?>
          <li><a href="homepage.php"><?php if (isset($_SESSION["loggedin"])) { echo "Hello ".$_SESSION["username"]; } ?></a></li>
           
        </ul>
      </nav>

    </div>
  </header><!-- End Header -->

  <!-- carousel -->
  <section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style= "background-image:url(img/pic.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp" style="animation-duration: 1.5s;"> 
              <h2>Welcome to <span>MobileComparison</span></h2>
              <p>An extensive online tool to compare mobile phones in India offers you to compare a mobile phone with other phones side by side in order to measure each specifications of a phone against the same feature of the other ones.</p>
              
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon bx bx-left-arrow" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon bx bx-right-arrow" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    </div>
  </section>
  <!-- carousel slider -->
  <section class="slider" >
      <ul id="autoWidth" class="cs-hidden">
      <!--1-->	
        <li class="item-a">
        <!--box-slider--------------->
          <div class="box">
            <!--img-box---------->
            <div class="slide-img">
              <img alt="1" src="img/iphone7.jpg">
                <!--overlayer---------->
                <div class="overlay">
                  <!--buy-btn------>	
                  <a href="#" class="buy-btn">Compare</a>	
                </div>
            </div>
            <!--detail-box--------->
            <div class="detail-box">
            <!--type-------->
              <div class="type">
                <a href="#">Apple Iphone7</a>
                
              </div>
          <!--price-------->
          <a href="#" class="price">24,999 Rs</a>            
          </div>       
        </div>		
      </li>
      <!--2-->	
      <li class="item-b">   
        <div class="box">       
          <div class="slide-img">
            <img alt="2" src="img/oppo A53.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">Oppo A53</a>
            
            </div>            
            <a href="#" class="price">12,990 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--3-->	
      <li class="item-c">   
        <div class="box">       
          <div class="slide-img">
            <img alt="3" src="img/Redmi8A.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">Redmi 8A</a>
              
            </div>            
            <a href="#" class="price">6,999 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--4-->
      <li class="item-d">   
        <div class="box">       
          <div class="slide-img">
            <img alt="4" src="img/googlepixel.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">GooglePixel 3XL</a>
              
            </div>            
            <a href="#" class="price">54,990 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--5-->
      <li class="item-e">   
        <div class="box">       
          <div class="slide-img">
            <img alt="5" src="img/oppoA12.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">Oppo A12</a>
              
            </div>            
            <a href="#" class="price">11,490 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--6-->
      <li class="item-f">   
        <div class="box">       
          <div class="slide-img">
            <img alt="6" src="img/oppoA52.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">Oppo A52</a>
              
            </div>            
            <a href="#" class="price">13,990 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--7-->
      <li class="item-g">   
        <div class="box">       
          <div class="slide-img">
            <img alt="7" src="img/motoE6s.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">Moto E6s</a>
          
            </div>            
            <a href="#" class="price">12,889 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--8-->
      <li class="item-h">   
        <div class="box">       
          <div class="slide-img">
            <img alt="8" src="img/oneplus 7t.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">OnePLus 7t</a>
            
            </div>            
            <a href="#" class="price">30,997 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--9-->
      <li class="item-i">   
        <div class="box">       
          <div class="slide-img">
            <img alt="9" src="img/oppoF17pro.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">Oppo F17 Pro</a>
              
            </div>            
            <a href="#" class="price">22,990 Rs</a>           
          </div>      
        </div>		
      </li>
      <!--10-->
      <li class="item-j">   
        <div class="box">       
          <div class="slide-img">
            <img alt="10" src="img/redmi9A.jpg">            
            <div class="overlay">           
              <a href="#" class="buy-btn">Compare</a>	
            </div>
          </div>         
          <div class="detail-box">        
            <div class="type">
              <a href="#">Redmi 9A</a>
            
            </div>            
            <a href="#" class="price">6,799 Rs</a>           
          </div>      
        </div>		
      </li>
      
    </ul>
	</section>
  <!----About---->
  <section id="about">
  <div class="container">
    <div class="row">
      <div class="col-md-4 skills-bar" >
        <h2>About Us</h2>
        <div class="about-content">
          This website allows anyone to not only compare mobile prices, but it also allows to compare mobile phones specifications. Through this online mobile comparison tool, you can compare mobile phone features side by side.

          The compare feature that we offer helps you in finding out the best smartphone that suits your requirements in the shortest amount of time.




        </div>
        
      </div>
      <div class="col-md-4">
        <p>html</p>
        <div class="progress">
          <div class="progress-bar" style="width:80%;">80%</div>
        </div>
        <p>html</p>
        <div class="progress">
          <div class="progress-bar" style="width:85%;">85%</div>
        </div>
        <p>html</p>
        <div class="progress">
          <div class="progress-bar" style="width:50%;">50%</div>
        </div>
        <p>html</p>
        <div class="progress">
          <div class="progress-bar" style="width:20%;">20%</div>
        </div>

      </div>
    </div>
  </div>
  
  
  </section>
  <!---contact--->
  <?php
    require_once 'connection.php';
      if(isset($_POST['submit1'])){

          $name1 = $_POST['name'];
          $phoneno1 = $_POST['phoneno'];
          $email1 = $_POST['email'];
          $message1 = $_POST['message'];
          $insertquery = "insert into contact(name,phoneno,email,message)values('$name1','$phoneno1','$email1','$message1')";

          $iquery = mysqli_query($conn,$insertquery);

              if($iquery){
                  ?>
                      <script>
                           alert("Thanks For Feedback.");
                          location.replace("homepage.php");
                      </script>
                  <?php

                  }else{
                  ?>
                       <script>
                           alert("Failed to send feedback.");
                       </script>
                  <?php

              }
      }
  ?>
  <form method="post">
  <section id="contact">
    <div class="container">
      <h1 style="text-align: center;"> Contact Us </h1>
      <div class="row">
        <div class="col-md-6">
          <form class="contact-form">
            <div class="form-group">
              <input name="name"     type="text" class="form-control" placeholder="Your Name">
            </div>
            <div class="form-group">
              <input name="phoneno"  type="number" class="form-control" placeholder="Phone no.">
            </div>
            <div class="form-group">
              <input name="email"  type="email" class="form-control" placeholder="Email Id">
            </div>
            <div class="form-group">
              <textarea name="message"   class="form-control" row="4" placeholder="Message"></textarea>
            </div>
            <button action="#" name="submit1" type="submit" class="btn btn-dark"> SEND</button>
          </form>
        </div>
        <div class="col-md-6 contact-info  " style="margin-top: 15px;">
          <div class="follow"><i class="icofont-location-pin"></i> <b>Address:</b>  ABC road Mumbai,India</div><br>

          <div class="follow"> <i class="icofont-email"></i> <b>EmailId :</b> sandesh03@gmail.com</div><br>

          <div class="follow"> <i class="icofont-smart-phone"></i><b>Phone no:</b>  35468978</div>
        </div>
        



          
        </div>
      </div>
    </div>
  </section>
</form>

<!-- footer -->
        <footer class="footer">
            <div class="footer-left col-md-4 col-sm-6">
              <p class="about" style="font-size: 20px;">
                This is just a college project.
              </p>
              <div class="icons">
                <a href="#"><i class="icofont-facebook"></i></a>
                <a href="#"><i class="icofont-twitter"></i></a>
                <a href="#"><i class="icofont-linkedin"></i></a>
                <a href="#"><i class="icofont-instagram"></i></i></a>
                
              </div>
            </div>
            <div class="footer-center col-md-4 col-sm-6">
              <div>
                <i class="icofont-location-pin"></i>
                <p><span> J.M road</span> Mumbai, India</p>
              </div>
              <div>
                <i class="icofont-smart-phone"></i>
                <p> 0123456789</p>
              </div>
              <div>
                <i class="icofont-email"></i>
                <p><a href="#">sandesh03@gmail.com</a></p>
              </div>
            </div>
            <div class="footer-right col-md-4 col-sm-6">
              <h2>Mobile<span>Comparison</span></h2>
              <p class="menu">
                <a href="#"> Home</a> |
                <a href="#"> Compare</a> |
                <a href="#"> About</a> |              
                <a href="#"> Contact</a>
              </p>
              
            </div>
          </footer>
          <!--footer-end-->
          <script src="">js/smooth-scroll.js</script>
          <script>
            var scroll= new SmoothScroll('a[href*="#"]');
          </script>
  
 <!-- js files          -->
  <script src="wow/wow.min.js"></script>
  <script>
    new WOW().init();
  </script>
  <script src="jquery/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>  
  <script src="owl.carousel/owl.carousel.min.js"></script>
  <script src="js/main.js"></script>
  <script src="lightslider/dist/js/lightslider.js"></script>

  <!-- lightslider js -->
  <script>
    $(document).ready(function() {
    $('#autoWidth').lightSlider({
        autoWidth:true,
        loop:true,
        auto:true,
        onSliderLoad: function() {
            $('#autoWidth').removeClass('cS-hidden');
        } 
    });  
  });
  </script>
</body>
</body>
</html>