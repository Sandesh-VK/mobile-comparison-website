<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Muli:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="lightslider/dist/css/lightslider.css">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="icofont/icofont.min.css" rel="stylesheet"> 
    <link href="animate.css/animate.min.css" rel="stylesheet"> 
    <link href="owl.carousel/owl.carousel.min.css" rel="stylesheet">
    <link rel="stylesheet" href="material-icon/css/material-design-iconic-font.min.css">
    <!-- animate on scroll -->
    <link href="aos/aos.css" rel="stylesheet">

    <!-- custom CSS File -->
    <link href="style1.css" rel="stylesheet">
    
</head>
<body>
    <?php 
        require_once 'connection.php';
        if(isset($_POST['submit'])){
            $username = $_POST['username'];
            $password = md5($_POST['password']);

            $loginquery = "select * from users where username= '$username' AND password='$password'";
            $query = mysqli_query($conn,$loginquery);

            $username_count = mysqli_num_rows($query);
            if($username_count){
                $user = mysqli_fetch_assoc($query);
                $_SESSION["loggedin"]=true;
                $_SESSION["username"]=$user["username"];

                   ?>
                        <script>
                            alert("Logged In.");
                            location.replace("homepage.php");
                        </script>
                    <?php
            }
            else{
                $password_error = 'Email or password is incorrect. Try again or click Forgot password to reset it.';
            }

            
        }   
    ?>
    <section class="sign-in">
        <div class="container">
            <div class="signin-content">
                <div class="signin-image">
                    <figure><img src="img/login1.png" alt="sing up image"></figure>
                    <a href="Register.php" class="signup-image-link">Create an account</a>
                </div>

                <div class="signin-form">
                    <h2 class="form-title">Log in</h2>
                    <form method="POST" class="register-form" id="login-form">
                        <div class="form-group">
                            <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                            <input type="text" name="username" id="your_name" placeholder="Username"/>
                        </div>
                        <div class="form-group">
                            <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                            <input type="password" name="password" id="your_pass" placeholder="Password"/>
                        </div>
                        <div class="form-group">
                            <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                            <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                        </div>
                        <div class="form-group form-button">
                            <input type="submit" name="submit" id="signin" class="form-submit" value="Log in"/>
                        </div>
                    </form>                   
                </div>
            </div>
        </div>
    </section>
</body>
</html>